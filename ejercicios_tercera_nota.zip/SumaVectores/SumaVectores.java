
import java.util.*;
import java.io.*;

// Ejercicio 1

class SumaVectores {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] vector1 = new int[5];
        int[] vector2 = new int[5];
        int[] vector3 = new int[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese el valor " + (i + 1) + " para vector1: ");
            vector1[i] = input.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese el valor " + (i + 1) + " para vector2: ");
            vector2[i] = input.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            vector3[i] = vector1[i] + vector2[i];
        }
        System.out.println("\nVector3 (suma de vector1 y vector2):");
        for (int i = 0; i < 5; i++) {
            System.out.println(vector3[i]);
        }
    }
}

// Ejercicio 9 - VectorCadenas (invertido)

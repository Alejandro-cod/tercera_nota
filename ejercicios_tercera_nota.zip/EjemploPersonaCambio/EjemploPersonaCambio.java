
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploPersonaCambio {
    public static void cambiarNombre(Persona persona) {
        persona.nombre = "Pedro";
        System.out.println("Dentro de cambiarNombre: " + persona.nombre);
    }
    public static void main(String[] args) {
        Persona persona = new Persona();
        persona.nombre = "Juan";
        cambiarNombre(persona);
        System.out.println("Después de cambiarNombre: " + persona.nombre);
    }
}

// Ejercicio 33 - Reasignar persona

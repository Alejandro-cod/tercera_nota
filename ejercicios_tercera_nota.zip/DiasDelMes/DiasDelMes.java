
import java.util.*;
import java.io.*;

// Ejercicio 1

class DiasDelMes {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] meses = {
            "Enero", "Febrero", "Marzo", "Abril",
            "Mayo", "Junio", "Julio", "Agosto",
            "Septiembre", "Octubre", "Noviembre", "Diciembre"
        };
        int[] dias = {
            31, 28, 31, 30,
            31, 30, 31, 31,
            30, 31, 30, 31
        };
        System.out.print("Ingrese un número de mes (1-12): ");
        int numeroMes = input.nextInt();
        if (numeroMes < 1 || numeroMes > 12) {
            System.out.println("Número de mes inválido.");
        } else {
            System.out.println("Mes: " + meses[numeroMes - 1]);
            System.out.println("Días: " + dias[numeroMes - 1]);
        }
    }
}

// Ejercicio 8 - SumaVectores


import java.util.*;
import java.io.*;

// Ejercicio 1

class VectorDiezElementos {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] vector = new int[10];
        int contador = 0;
        while (contador < 10) {
            System.out.print("Ingrese un número (negativo para terminar): ");
            int numero = input.nextInt();
            if (numero < 0) {
                break;
            }
            vector[contador] = numero;
            contador++;
        }
        System.out.println("\nElementos introducidos:");
        for (int i = 0; i < contador; i++) {
            System.out.println(vector[i]);
        }
    }
}

// Ejercicio 6 - OrdenarVector

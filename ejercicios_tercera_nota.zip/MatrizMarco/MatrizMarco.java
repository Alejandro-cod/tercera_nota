
import java.util.*;
import java.io.*;

// Ejercicio 1

class MatrizMarco {
    public static void main(String[] args) {
        int[][] marco = new int[5][15];
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 15; j++)
                marco[i][j] = (i == 0 || i == 4 || j == 0 || j == 14) ? 1 : 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 15; j++) System.out.print(marco[i][j] + " ");
            System.out.println();
        }
    }
}

// Ejercicio 17 - ConductoresKilometros

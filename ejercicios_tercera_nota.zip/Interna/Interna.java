
import java.util.*;
import java.io.*;

// Ejercicio 1

class Interna {
        public void mostrarMensaje() {
            System.out.println(mensaje);
        }
    }
    public static void main(String[] args) {
        Externa externa = new Externa();
        Externa.Interna interna = externa.new Interna();
        interna.mostrarMensaje();
    }
}

// Ejercicio 40 - EjemploArrayList

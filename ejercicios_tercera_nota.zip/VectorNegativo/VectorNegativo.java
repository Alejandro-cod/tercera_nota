
import java.util.*;
import java.io.*;

// Ejercicio 1

class VectorNegativo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] v = new int[10];
        int i = 0;
        while (i < 10) {
            int num = input.nextInt();
            if (num < 0) break;
            v[i] = num;
            i++;
        }
        for (int j = 0; j < i; j++) System.out.println(v[j]);
    }
}

// Ejercicio 13 - TemperaturasDias

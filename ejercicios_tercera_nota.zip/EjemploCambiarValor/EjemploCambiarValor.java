
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploCambiarValor {
    public static void cambiarValor(int num) {
        num = 10;
        System.out.println("Dentro de cambiarValor: " + num);
    }
    public static void main(String[] args) {
        int numero = 5;
        cambiarValor(numero);
        System.out.println("Después de llamar a cambiarValor: " + numero);
    }
}

// Ejercicio 32 - Persona cambiarNombre

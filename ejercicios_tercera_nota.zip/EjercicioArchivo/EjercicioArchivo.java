
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjercicioArchivo {
    public static void main(String[] args) {
        try {
            String nombreArchivo = "ejemplo.txt";
            PrintWriter pw = new PrintWriter(new FileWriter(nombreArchivo));
            pw.println("Archivo de ejemplo creado por Ejercicios.");
            pw.close();
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
            String linea;
            while ((linea = br.readLine()) != null) System.out.println(linea);
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

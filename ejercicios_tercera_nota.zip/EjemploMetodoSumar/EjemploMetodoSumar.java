
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploMetodoSumar {
    public static int sumar(int a, int b) {
        return a + b;
    }
    public static void main(String[] args) {
        int resultado = sumar(5,3);
        System.out.println("Resultado: " + resultado);
    }
}

// Ejercicio 30 - Encontrar mayor

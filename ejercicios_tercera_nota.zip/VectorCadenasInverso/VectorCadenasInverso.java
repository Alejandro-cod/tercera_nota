
import java.util.*;
import java.io.*;

// Ejercicio 1

class VectorCadenasInverso {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] vector = new String[5];
        String[] vectorInverso = new String[5];
        for (int i = 0; i < vector.length; i++) {
            System.out.print("Ingrese una cadena para la posición " + (i + 1) + ": ");
            vector[i] = input.nextLine();
        }
        for (int i = 0; i < vector.length; i++) {
            vectorInverso[i] = vector[vector.length - 1 - i];
        }
        System.out.println("\nVector en orden inverso:");
        for (int i = 0; i < vectorInverso.length; i++) {
            System.out.println(vectorInverso[i]);
        }
    }
}

// Ejercicio 4 - NotasAlumno

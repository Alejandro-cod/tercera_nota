
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploArrayList {
    public static void main(String[] args) {
        ArrayList<String> lista = new ArrayList<>();
        lista.add("Java");
        lista.add("Python");
        lista.add("JavaScript");
        for (String lenguaje : lista) System.out.println(lenguaje);
    }
}

// Ejercicio 41 - Archivo final: ejemplo de lectura/escritura simple

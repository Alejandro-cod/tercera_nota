
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploGC {
    public static void main(String[] args) {
        EjemploGC obj = new EjemploGC();
        obj = null;
        System.gc();
    }
    @Override
    protected void finalize() throws Throwable {
        System.out.println("El objeto se está eliminando");
    }
}

// Ejercicio 36 - Sobrecarga

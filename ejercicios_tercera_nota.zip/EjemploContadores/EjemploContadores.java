
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploContadores {
    public static void main(String[] args) {
        int[] numeros = {1,2,3,4,5,6};
        int contadorPares = 0;
        for (int numero : numeros) {
            if (numero % 2 == 0) contadorPares++;
        }
        System.out.println("Cantidad de números pares: " + contadorPares);
    }
}

// Ejercicio 25 - Suma 1..5

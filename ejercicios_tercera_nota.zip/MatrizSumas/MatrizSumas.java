
import java.util.*;
import java.io.*;

// Ejercicio 1

class MatrizSumas {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[][] matriz = new int[5][5];
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                matriz[i][j] = input.nextInt();
        System.out.println("\nSuma de cada fila:");
        for (int i = 0; i < 5; i++) {
            int sumaFila = 0;
            for (int j = 0; j < 5; j++) sumaFila += matriz[i][j];
            System.out.println("Fila " + (i + 1) + ": " + sumaFila);
        }
        System.out.println("\nSuma de cada columna:");
        for (int j = 0; j < 5; j++) {
            int sumaColumna = 0;
            for (int i = 0; i < 5; i++) sumaColumna += matriz[i][j];
            System.out.println("Columna " + (j + 1) + ": " + sumaColumna);
        }
    }
}

// Ejercicio 15 - MatrizDiagonal

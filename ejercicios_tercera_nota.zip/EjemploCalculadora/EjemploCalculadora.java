
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploCalculadora {
    public static void main(String[] args) {
        Calculadora calc = new Calculadora();
        System.out.println("Suma de 2 enteros: " + calc.sumar(5,10));
        System.out.println("Suma de 3 enteros: " + calc.sumar(5,10,15));
        System.out.println("Suma de 2 doubles: " + calc.sumar(5.5,10.5));
        System.out.println("Resta de 2 enteros: " + calc.restar(20,10));
    }
}

// Ejercicio 35 - EjemploGC (note: finalize deprecated but included)


import java.util.*;
import java.io.*;

// Ejercicio 1

class EmpresaArticulos2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] precios = new double[5];
        int[][] cantidades = new int[5][4];
        double[] recaudacionSuc = new double[4];
        for (int i = 0; i < 5; i++) {
            System.out.print("Precio del artículo " + (i + 1) + ": ");
            precios[i] = input.nextDouble();
        }
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 4; j++)
                cantidades[i][j] = input.nextInt();
        for (int j = 0; j < 4; j++) {
            double suma = 0;
            for (int i = 0; i < 5; i++) suma += cantidades[i][j] * precios[i];
            recaudacionSuc[j] = suma;
        }
        double totalEmpresa = 0;
        for (double r : recaudacionSuc) totalEmpresa += r;
        System.out.println("Recaudación total de la empresa: " + totalEmpresa);
    }
}

// Ejercicio 19 - Quiniela

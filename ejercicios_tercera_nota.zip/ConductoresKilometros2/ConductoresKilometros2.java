
import java.util.*;
import java.io.*;

// Ejercicio 1

class ConductoresKilometros2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese la cantidad de conductores: ");
        int n = input.nextInt();
        input.nextLine();
        String[] nombre = new String[n];
        int[][] kms = new int[n][7];
        int[] total_kms = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("Nombre del conductor " + (i + 1) + ": ");
            nombre[i] = input.nextLine();
            for (int j = 0; j < 7; j++) {
                System.out.print("Kms del día " + (j + 1) + " del conductor " + nombre[i] + ": ");
                kms[i][j] = input.nextInt();
            }
            input.nextLine();
        }
        for (int i = 0; i < n; i++) {
            int suma = 0;
            for (int j = 0; j < 7; j++) suma += kms[i][j];
            total_kms[i] = suma;
        }
        System.out.println("\nListado de kilómetros por conductor:");
        for (int i = 0; i < n; i++) {
            System.out.println(nombre[i] + " -> " + total_kms[i] + " kms");
        }
    }
}

// Ejercicio 18 - EmpresaArticulos


import java.util.*;
import java.io.*;

// Ejercicio 1

class Rectangulo {
    int ancho;
    int alto;
    Rectangulo(int ancho, int alto) {
        this.ancho = ancho;
        this.alto = alto;
    }
}


import java.util.*;
import java.io.*;

// Ejercicio 1

class VectorCadenas {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] v1 = new String[5];
        String[] v2 = new String[5];
        for (int i = 0; i < 5; i++) v1[i] = input.nextLine();
        for (int i = 0; i < 5; i++) v2[i] = v1[4-i];
        for (int i = 0; i < 5; i++) System.out.println(v2[i]);
    }
}

// Ejercicio 10 - VectorCuadradoCubo (parcial)

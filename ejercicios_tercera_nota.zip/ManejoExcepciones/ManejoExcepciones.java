
import java.util.*;
import java.io.*;

// Ejercicio 1

class ManejoExcepciones {
    public static void main(String[] args) {
        try {
            int resultado = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Error: División por cero.");
        } finally {
            System.out.println("Este bloque se ejecuta siempre.");
        }
    }
}

// Ejercicio 39 - Clase externa e interna


import java.util.*;
import java.io.*;

// Ejercicio 1

class Calculadora {
    public int sumar(int a, int b) { return a + b; }
    public int sumar(int a, int b, int c) { return a + b + c; }
    public double sumar(double a, double b) { return a + b; }
    public int restar(int a, int b) { return a - b; }
}

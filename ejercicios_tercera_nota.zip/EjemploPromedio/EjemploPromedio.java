
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploPromedio {
    public static void main(String[] args) {
        int[] calificaciones = {80,90,70,85,95};
        int sumaCalificaciones = 0;
        for (int calificacion : calificaciones) sumaCalificaciones += calificacion;
        double promedio = (double) sumaCalificaciones / calificaciones.length;
        System.out.println("El promedio de calificaciones es: " + promedio);
    }
}

// Ejercicio 27 - Positivos y suma negativos


import java.util.*;
import java.io.*;

// Ejercicio 1

class TemperaturasDias {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] tempMin = new double[5];
        double[] tempMax = new double[5];
        for (int i = 0; i < 5; i++) {
            System.out.print("Ingrese la temperatura mínima del día " + (i + 1) + ": ");
            tempMin[i] = input.nextDouble();
            System.out.print("Ingrese la temperatura máxima del día " + (i + 1) + ": ");
            tempMax[i] = input.nextDouble();
        }
        System.out.println("\nTemperatura media de cada día:");
        for (int i = 0; i < 5; i++) {
            double media = (tempMin[i] + tempMax[i]) / 2;
            System.out.println("Día " + (i + 1) + ": " + media);
        }
        double menorTemp = tempMin[0];
        for (int i = 1; i < 5; i++) if (tempMin[i] < menorTemp) menorTemp = tempMin[i];
        System.out.println("\nDías con menor temperatura mínima (" + menorTemp + "):");
        for (int i = 0; i < 5; i++) if (tempMin[i] == menorTemp) System.out.println("Día " + (i + 1));
        System.out.print("\nIngrese una temperatura para buscar coincidencias en temperaturas máximas: ");
        double buscada = input.nextDouble();
        boolean encontrado = false;
        System.out.println("\nDías con temperatura máxima igual a " + buscada + ":");
        for (int i = 0; i < 5; i++) {
            if (tempMax[i] == buscada) {
                System.out.println("Día " + (i + 1));
                encontrado = true;
            }
        }
        if (!encontrado) System.out.println("No existe ningún día con esa temperatura máxima.");
    }
}

// Ejercicio 14 - MatrizSumas

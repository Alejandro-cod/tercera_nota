
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploMayor {
    public static int encontrarMayor(int a, int b, int c) {
        return Math.max(a, Math.max(b, c));
    }
    public static void main(String[] args) {
        int mayor = encontrarMayor(10,20,5);
        System.out.println("El número mayor es: " + mayor);
    }
}

// Ejercicio 31 - Cambiar valor primitivo

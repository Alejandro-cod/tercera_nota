
import java.util.*;
import java.io.*;

// Ejercicio 1

class OrdenarVector {
    public static void main(String[] args) {
        int[] numeros = new int[10];
        Random random = new Random();
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(100);
        }
        Arrays.sort(numeros);
        System.out.println("Vector ordenado:");
        for (int num : numeros) {
            System.out.println(num);
        }
    }
}

// Ejercicio 7 - DiasDelMes

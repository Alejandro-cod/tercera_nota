
import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploSuma {
    public static void main(String[] args) {
        int suma = 0;
        for (int i = 1; i <= 5; i++) suma += i;
        System.out.println("La suma total es: " + suma);
    }
}

// Ejercicio 26 - Promedio calificaciones


import java.util.*;
import java.io.*;

// Ejercicio 1

class Externa {
    private String mensaje = "¡Hola desde la clase externa!";
    public 

import java.util.*;
import java.io.*;

// Ejercicio 1

class Ejercicio4Incrementar {
    public static int incrementar(int x) {
        x += 1;
        System.out.println("Dentro del método: x = " + x);
        return x;
    }
    public static void main(String[] args) {
        int x = 5;
        System.out.println("Antes de llamar al método: x = " + x);
        x = incrementar(x);
        System.out.println("Después de llamar al método: x = " + x);
    }
}

// Ejercicio 23 - Ejercicio5 modificarCadena


import java.util.*;
import java.io.*;

// Ejercicio 1

class MatrizDiagonal {
    public static void main(String[] args) {
        int[][] diagonal = new int[5][5];
        for (int i = 0; i < 5; i++)
            for (int j = 0; j < 5; j++)
                diagonal[i][j] = (i == j) ? 1 : 0;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) System.out.print(diagonal[i][j] + " ");
            System.out.println();
        }
    }
}

// Ejercicio 16 - MatrizMarco

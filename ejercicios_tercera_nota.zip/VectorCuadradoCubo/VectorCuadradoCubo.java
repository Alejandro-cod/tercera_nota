
import java.util.*;
import java.io.*;

// Ejercicio 1

class VectorCuadradoCubo {
    public static void main(String[] args) {
        int[] numeros = {1,2,3,4,5,6,7,8,9,10};
        for (int numero : numeros) {
            int cuadrado = numero * numero;
            int cubo = numero * numero * numero;
            System.out.println("Número: " + numero + " | Cuadrado: " + cuadrado + " | Cubo: " + cubo);
        }
    }
}

// Ejercicio 11 - NotasAlumnoSimple (parcial)

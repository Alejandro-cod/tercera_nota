
import java.util.*;
import java.io.*;

// Ejercicio 1

class Persona {
    String nombre;
}


import java.util.*;
import java.io.*;

// Ejercicio 1

class Quiniela2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[][] equipos = new String[15][2];
        int[][] resultados = new int[15][2];
        System.out.println("=== INGRESO DE DATOS DE LA QUINIELA ===");
        for (int i = 0; i < 15; i++) {
            System.out.println("\nPartido " + (i + 1));
            System.out.print("Nombre del equipo LOCAL: ");
            equipos[i][0] = input.nextLine();
            System.out.print("Nombre del equipo VISITANTE: ");
            equipos[i][1] = input.nextLine();
            System.out.print("Goles del equipo LOCAL: ");
            resultados[i][0] = Integer.parseInt(input.nextLine());
            System.out.print("Goles del equipo VISITANTE: ");
            resultados[i][1] = Integer.parseInt(input.nextLine());
        }
        System.out.println("\n=== RESULTADOS DE LA QUINIELA ===");
        for (int i = 0; i < 15; i++) {
            System.out.println((i + 1) + ". " + equipos[i][0] + " " + resultados[i][0] + " - " + resultados[i][1] + " " + equipos[i][1]);
        }
    }
}

// Ejercicio 20 - Rectangulo / Ejercicio2 from snippet

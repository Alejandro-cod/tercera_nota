
import java.util.*;
import java.io.*;

// Ejercicio 1

class NotasAlumnoSimple {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double[] notas = new double[5];
        for (int i = 0; i < notas.length; i++) notas[i] = input.nextDouble();
        double suma = 0;
        for (double n : notas) suma += n;
        System.out.println("Media: " + (suma / notas.length));
    }
}

// Ejercicio 12 - VectorNegativo


import java.util.*;
import java.io.*;

// Ejercicio 1

class EjemploReasignarPersona {
    public static void cambiarPersona(Persona persona) {
        persona = new Persona();
        persona.nombre = "Pedro";
        System.out.println("Dentro de cambiarPersona: " + persona.nombre);
    }
    public static void main(String[] args) {
        Persona persona = new Persona();
        persona.nombre = "Juan";
        cambiarPersona(persona);
        System.out.println("Después de cambiarPersona: " + persona.nombre);
    }
}

// Ejercicio 34 - Calculadora con sobrecarga
